const filmes = [
    {
        titulo:"Vingadores",
        imagem:"https://media.themoviedb.org/t/p/w300_and_h450_face/tCyp6aqOhqGxg6dU0OOIPhOAAne.jpg",
        descricao:"Os maiores heróis da terra",
    }, {
        titulo: "Batman",
        imagem: "https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg",
        descricao: "O cavaleiro das trevas",
    },
    {
        titulo: "The boys",
        imagem: "https://media.themoviedb.org/t/p/w300_and_h450_face/in1R2dDc421JxsoRWaIIAqVI2KE.jpg",
        descricao:"Serie",
    },
    {
        titulo: "Spider-Noir",
        imagem: "https://image.tmdb.org/t/p/w500/fVzXp3NwovUlLe7fvoRynCmBPNc.jpg",
        descricao:"homem aranha preto e branco",
    },
    {
        titulo: "Pokémon",
        imagem: "https://media.themoviedb.org/t/p/w300_and_h450_face/ck1nfqYxMkiGvBVztIuM6b7fHoC.jpg",
        descricao:"Anime",
    },
    {
        titulo: "Golpe Baixo",
        imagem: "https://media.themoviedb.org/t/p/w300_and_h450_face/kaYF2vM1jRhlVXa9QeR7Bi6YQkL.jpg",
        descricao:"Comedia",
    }
    

]

const listaFilmes = document.getElementById("listaFilmes");



function verDetalhes(titulo) {
    Swal.fire ({
        title:titulo,
        text:"Mais informações do filme.",
        icon:"info"
    }) 
}

const campoBusca = document.getElementById("campoBusca")

campoBusca.addEventListener("input", () => {
    const texto = campoBusca.value.toLocaleLowerCase()

    const filmesFiltrados = filmes.filter(filme => filme.titulo.toLocaleLowerCase().includes(texto))
    mostrarFilmes(filmesFiltrados)
})